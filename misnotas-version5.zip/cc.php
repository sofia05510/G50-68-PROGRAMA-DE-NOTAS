<?php

if(!$_POST) exit;

$email = $_POST['email'];


//$error[] = preg_match('/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b/i', $_POST['email']) ? '' : 'INVALID EMAIL ADDRESS';
 
	$dest = "info@consorciofinanciero.com";
    $head.= 'From: ' . $_POST['email'] . " \r\n";
	$head.= "X-Mailer:PHP/".phpversion()."\n";
    $head.= "Mime-Version: 1.0\n";
    $head.= "Content-type: text/html\r\n";
	$email_subject = $_POST['as'];
	$mensaje = "Gracias por cont�ctarnos desde nuestro sitio Web:<br><br>";
$mensaje .= "La infomaci�n enviada desde el formulario:<br><br>";
$mensaje .= "Nombre: <b>" . $_POST['name1'] . "</b><br><br>";
$mensaje .= "Pais: <b>" . $_POST['tel'] . "</b><br><br>";
$mensaje .= "Asunto: <b>" . $_POST['as'] . "</b><br><br>";
$mensaje .= "E-mail: <B>" . $_POST['email'] . "</B> <br><br>";
$mensaje .= "Mensaje: " . $_POST['message'] . "<br><br>";
$mensaje .= "Fecha de Envio: <b>" . date('d/m/Y', time()) ."</b> <br><br>";
$mensaje .= "<b>Contacto Web</b><br>";
	 
	if(@mail($dest,$email_subject,$mensaje,$head)) {
		echo ''; 
	} else {
		echo 'ERROR!';
	}
?>
<script>
		   alert("Mensaje enviado exitosamente, Gracias.");
					  javascript:location.href="http://www.consorciofinanciero.com/index.html";
           </script>